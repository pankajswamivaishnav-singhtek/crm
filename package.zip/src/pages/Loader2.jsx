import React from "react";
import "../styles/loader2.css";
const Loader = () => {
  return <div class="loader2"></div>;
};

export default Loader;
