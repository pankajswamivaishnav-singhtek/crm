import { createContext } from "react";

const leadIdContext = createContext();

export default leadIdContext;
