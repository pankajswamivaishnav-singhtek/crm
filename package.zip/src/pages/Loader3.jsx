import React from "react";
import "../styles/loader3.css";
const Loader = () => {
  return <div className="loader3"></div>;
};

export default Loader;
